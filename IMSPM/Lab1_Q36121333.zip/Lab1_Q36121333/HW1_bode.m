close all; clear; clc;
s = tf('s');

%% ========= 規格（右邊表格）=========
Vg = 9;             % Vin [V]
Vo = 1.5;           % Vout [V]
fs = 500e3;         % switching [Hz]
L  = 10e-6;         % inductance [H]
rL = 20e-3;         % inductor ESR [ohm]
C  = 22e-6;         % capacitance [F]
rC = 20e-3;         % capacitor ESR [ohm]

% 負載（選 0.5 A 或 1 A）
Iload_A = 0.5;                % 改成 1.0 看 1A
Rload   = Vo / Iload_A;

%% ========= Buck 小訊號 control-to-output =========
w0 = 1/sqrt(L*C);                    % LC natural rad/s
wz = 1/(rC*C);                       % ESR zero
Q  = (1/w0) * 1/( L/(Rload+rL) + C*( rC + rL*Rload/(rL+Rload) ) );

Gvd = Vg * (1 + s/wz) / (1 + s/(Q*w0) + (s/w0)^2);  % control->Vout

% 感測與調變器增益（與你之前腳本一致）
Hsense = 1;     % 分壓/ADC 轉換等（先設 1）
VM     = 3;     % 調變器等效增益（鋸齒峰值等）
Plant  = Hsense*(1/VM)*Gvd;         % P(s)
%sisotool(Plant);
fprintf('[PLANT]  Rload=%.3f ohm,  f0=%.1f kHz,  f_ESR=%.1f kHz,  Q=%.2f\n',...
        Rload, w0/2/pi/1e3, wz/2/pi/1e3, Q);

%% ========= PID 補償器（並聯式，含微分濾波）=========
fc = fs/2.1;                 % 交越目標 (50 kHz)
w_c = 2*pi*fc;

% ---- 一組保守好用的零點配置 ----
% 穩定電源控制常見設法：積分零點放在 fc/10，微分零點放在 fc/3 左右
fi = fc/40;                 % 积分零點頻率
fd = fc/3;                  % 微分零點頻率
Ti = 1/(2*pi*fi);
Td = 1/(2*pi*fd);

% 微分濾波極點：放在 fc*10（微分高頻滾降，避免噪聲）
wf = 2*pi*(500*fc);

% ---- 無比例增益的 PID 原型（Kp=1 先建立形狀）----
Gc0_pid = 1 + 1/(Ti*s) + (Td*s)/(1 + s/wf);


% ---- 求 Kp，讓 |Kp*Gc0_pid*Plant| 在 fc 交越 = 1 ----
mag_at_fc = abs( squeeze( freqresp(Gc0_pid*Plant, w_c) ) );
Kp = 1 / mag_at_fc;

% ---- 手算 PID ----
%Gc_pid = Kp * Gc0_pid;
% ---- sisotool PID ----
Gc_pid=(28*(s-650)*(s-1.220))/((s-1.674e03)*(s-5.815e04));
% ---- 重新檢查相位/增益裕度 ----
L_s = Gc_pid * Plant;
[GM, PM, Wcg, Wcp] = margin(L_s);
fprintf('[PID]    fi=%.1f kHz, fd=%.1f kHz, Kp=%.3f\n', fi/1e3, fd/1e3, Kp);
fprintf('[MARGIN] PM=%.1f deg @ %.1f kHz, GM=%.2f @ %.1f kHz\n', ...
        PM, Wcp/2/pi/1e3, GM, Wcg/2/pi/1e3);

% ---- (選擇) 離散化到 PWM 取樣 Ts ----
Ts = 1/fs;
try
    opt = c2dOptions('Method','tustin','PrewarpFrequency', w_c);
    Gc_d = c2d(Gc_pid, Ts, opt);
catch
    Gc_d = c2d(Gc_pid, Ts, 'tustin', w_c);
end

[numd, dend] = tfdata(Gc_d,'v');
% 使分母首項=1（Simulink 慣例）
if abs(dend(1)-1) > 1e-12
    numd = numd / dend(1);
    dend = dend / dend(1);
end

disp('numd = '); disp(numd);
disp('dend = '); disp(dend);



    